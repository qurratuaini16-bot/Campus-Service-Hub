<?php
// Task 1e: Secure session handling
session_start();
include 'db_connect.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Task 7: Prevent XSS using htmlspecialchars
    $username = htmlspecialchars($_POST['username']); 
    
    // Task 1b: Use password_hash() for security (REQUIRED for Task 1)
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $role = 'User'; // Default role as per Task 1c

    // Task 7: Use Prepared Statements to prevent SQL Injection (REQUIRED for Task 7)
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $role);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>Yay! Registration successful! 🎉 </div>";
    } else {
        // Handle duplicate username or other errors gracefully (Task 4d)
        if ($conn->errno == 1062) {
            $message = "<div class='alert alert-danger'>Oh no! Username already taken! 👤</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $stmt->error . " 😕</div>";
        }
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Us | Campus Hub 🚀</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Fredoka', sans-serif;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .register-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 30px;
            padding: 40px;
            width: 90%;
            max-width: 420px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            text-align: center;
            border: 4px solid #fff;
            position: relative;
        }

        .emoji-header {
            font-size: 50px;
            margin-bottom: 10px;
        }

        h2 {
            font-weight: 600;
            color: #23a6d5;
            margin-bottom: 10px;
        }

        .form-label {
            display: block;
            text-align: left;
            font-weight: 600;
            color: #555;
            margin-bottom: 5px;
            margin-left: 5px;
        }

        .form-control {
            border-radius: 15px;
            padding: 12px 20px;
            border: 2px solid #eee;
            margin-bottom: 20px;
        }

        .form-control:focus {
            border-color: #e73c7e;
            box-shadow: 0 0 10px rgba(231, 60, 126, 0.2);
        }

        .btn-register {
            background: linear-gradient(to right, #23a6d5, #23d5ab);
            border: none;
            color: white;
            padding: 15px;
            border-radius: 15px;
            font-weight: 600;
            width: 100%;
            font-size: 1.1rem;
            transition: 0.3s;
            box-shadow: 0 4px 15px rgba(35, 166, 213, 0.4);
        }

        .btn-register:hover {
            transform: scale(1.05) rotate(1deg);
            filter: brightness(1.1);
        }

        .login-link {
            margin-top: 25px;
            font-size: 0.9rem;
            color: #666;
        }

        .login-link a {
            color: #23a6d5;
            text-decoration: none;
            font-weight: 600;
        }

        .alert {
            border-radius: 15px;
            font-weight: 600;
        }

        .star {
            position: absolute;
            z-index: -1;
            animation: rotateStar 10s infinite linear;
        }

        @keyframes rotateStar {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

    <div class="star" style="top: 15%; right: 15%; font-size: 30px;">⭐</div>
    <div class="star" style="bottom: 10%; left: 10%; font-size: 40px;">✨</div>

    <div class="register-card">
        <div class="emoji-header">📝✨</div>
        <h2>Join the Club!</h2>
        <p class="text-muted mb-4">Start your journey with Campus Hub</p>

        <?php if($message != "") echo $message; ?>

        <form method="POST" action="register.php">
            <div class="mb-1">
                <label class="form-label">👤 Choose a Username</label>
                <input type="text" name="username" class="form-control" placeholder="Exp : CoolGuy99" required>
            </div>

            <div class="mb-1">
                <label class="form-label">🔑 Set a Password</label>
                <input type="password" name="password" class="form-control" placeholder="Keep it secret! 🤫" required>
            </div>

            <button type="submit" class="btn btn-register">Create My Account 🎈</button>
        </form>

        <div class="login-link">
            Already a member? <a href="login.php">Log in here! 🔑</a>
        </div>
    </div>

</body>
</html>