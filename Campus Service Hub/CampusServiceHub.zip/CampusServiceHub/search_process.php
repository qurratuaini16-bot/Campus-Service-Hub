<?php
include 'db_connect.php';

$q = isset($_GET['q']) ? $_GET['q'] : '';

$query = "SELECT s.*, u.username FROM services s 
          JOIN users u ON s.user_id = u.id 
          WHERE s.title LIKE ? 
          OR s.category LIKE ? 
          OR s.description LIKE ?
          ORDER BY s.created_at DESC";

$stmt = $conn->prepare($query);
$searchTerm = "%$q%";

$stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '<div class="row">';
    while ($row = $result->fetch_assoc()) {
        ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm border-0" style="border-radius: 20px; overflow: hidden; transition: 0.3s;">
                <div style="position: relative;">
                    <img src="<?= htmlspecialchars($row['image']) ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                    
                    <span class="badge bg-primary" style="position: absolute; top: 15px; left: 15px; border-radius: 10px; padding: 8px 12px; background-color: #e73c7e !important;">
                        <?= htmlspecialchars($row['category']) ?>
                    </span>
                </div>
                
                <div class="card-body">
                    <h5 class="card-title fw-bold text-dark"><?= htmlspecialchars($row['title']) ?></h5>
                    <p class="text-muted small mb-2">By: <strong>@<?= htmlspecialchars($row['username']) ?></strong></p>
                    <p class="card-text text-muted" style="font-size: 0.9rem; height: 45px; overflow: hidden;">
                        <?= htmlspecialchars($row['description']) ?>
                    </p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="fw-bold text-success" style="font-size: 1.2rem;">RM <?= number_format($row['price'], 2) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    echo '</div>';
} else {
    
    echo '<div class="text-center text-white py-5">
            <span style="font-size: 3rem;">🕵️‍♂️</span>
            <h3 class="mt-3">No services found for "' . htmlspecialchars($q) . '"</h3>
            <p>Try searching for something else or check other categories!</p>
          </div>';
}
$stmt->close();
?>