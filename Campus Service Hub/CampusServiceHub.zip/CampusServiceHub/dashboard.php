<?php
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$count_query = "SELECT COUNT(*) as total FROM services WHERE user_id = ?";
$c_stmt = $conn->prepare($count_query);
$c_stmt->bind_param("i", $user_id);
$c_stmt->execute();
$count_res = $c_stmt->get_result()->fetch_assoc();
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="glass-card text-center p-4">
                <h2 class="fw-bold text-primary"><?= $count_res['total'] ?></h2>
                <p class="text-muted mb-0">Total Services Posted</p>
            </div>
        </div>
        <div class="col-md-8 d-flex align-items-center justify-content-end">
            <a href="add_service.php" class="btn btn-light btn-custom shadow-sm me-2">➕ Add New Service</a>
            <a href="index.php" class="btn btn-primary btn-custom shadow-sm">🔍 View All Services</a>
        </div>
    </div>

    <div class="glass-card mb-5">
        <h4 class="fw-bold mb-4">My Posted Services 📋</h4>
        
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Image</th>
                        <th>Service Title</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Ambil servis milik user yang sedang login sahaja menggunakan Prepared Statement
                    $query = "SELECT * FROM services WHERE user_id = ? ORDER BY created_at DESC";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0):
                        while ($row = $result->fetch_assoc()):
                    ?>
                        <tr>
                            <td><img src="<?= htmlspecialchars($row['image']) ?>" alt="Service"></td>
                            <td><strong><?= htmlspecialchars($row['title']) ?></strong></td>
                            <td>
                                <span class="badge bg-info text-dark rounded-pill px-3">
                                    <?= htmlspecialchars_decode($row['category']) ?>
                                </span>
                            </td>
                            <td class="text-success fw-bold">RM <?= number_format($row['price'], 2) ?></td>
                            <td class="text-center">
                                <a href="edit_service.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning rounded-pill px-3">Edit</a>
                                <a href="delete_service.php?id=<?= $row['id'] ?>" 
                                   class="btn btn-sm btn-danger rounded-pill px-3"
                                   onclick="return confirm('Are you sure you want to delete this service?')">Delete</a>
                            </td>
                        </tr>
                    <?php 
                        endwhile; 
                    else: 
                    ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                You haven't posted any services yet. <br>
                                <a href="add_service.php" class="text-primary fw-bold">Post your first service now!</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
include 'footer.php'; 
?>