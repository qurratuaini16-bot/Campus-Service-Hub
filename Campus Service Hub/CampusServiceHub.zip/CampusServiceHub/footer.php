<footer class="footer mt-auto py-5 text-center">
        <div class="container">
            <div class="p-3 rounded-pill" style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(5px); border: 1px solid rgba(255, 255, 255, 0.2);">
                <p class="text-white mb-0 small">
                    © 2026 <strong>Campus Service Hub</strong> - Politeknik Balik Pulau
                </p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>