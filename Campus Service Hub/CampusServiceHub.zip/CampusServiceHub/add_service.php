<?php
// Task 1e: Secure session handling
session_start();
include 'db_connect.php';

// Task 1e: Restrict unauthorized access
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Task 7: Security Practices (XSS prevention)
    $title = htmlspecialchars($_POST['title']);
    $category = htmlspecialchars($_POST['category']); // TAMBAH INI
    $description = htmlspecialchars($_POST['description']);
    $price = $_POST['price'];
    $user_id = $_SESSION['user_id'];

    // Task 3c & 4: File Upload handling with Validation
    $file_name = $_FILES['service_image']['name'];
    $file_size = $_FILES['service_image']['size'];
    $file_tmp = $_FILES['service_image']['tmp_name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    $extensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $extensions) === false) {
        $error = "Extension not allowed, please choose a JPG or PNG file. 🖼️";
    } elseif ($file_size > 2097152) { 
        $error = "File size must be less than 2 MB. ⚖️";
    } else {
        if (!is_dir('uploads')) {
            mkdir('uploads', 0777, true);
        }

        $new_file_name = time() . "_" . $file_name;
        $target_file = "uploads/" . $new_file_name;

        if (move_uploaded_file($file_tmp, $target_file)) {
            // KEMASKINI QUERY: Tambah 'category' dan satu lagi '?'
            $stmt = $conn->prepare("INSERT INTO services (user_id, title, category, description, price, image) VALUES (?, ?, ?, ?, ?, ?)");
            // KEMASKINI BIND: Tambah "s" untuk category dan letak pembolehubah $category
            $stmt->bind_param("isssds", $user_id, $title, $category, $description, $price, $target_file);
            
            if ($stmt->execute()) {
                $success = "Yay! Service added successfully! 🚀";
            } else {
                $error = "Database Error: " . $conn->error;
            }
            $stmt->close();
        } else {
            $error = "Failed to upload image. Check folder permissions. 📂";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service | Campus Hub ✨</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        body {
            margin: 0; padding: 0; font-family: 'Fredoka', sans-serif;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%; animation: gradient 15s ease infinite;
            min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px;
        }
        @keyframes gradient { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .form-card { background: rgba(255, 255, 255, 0.9); border-radius: 30px; padding: 40px; width: 100%; max-width: 550px; box-shadow: 0 20px 40px rgba(0,0,0,0.2); border: 4px solid #fff; }
        h3 { font-weight: 600; color: #e73c7e; text-align: center; }
        .form-label { font-weight: 600; color: #555; margin-left: 5px; }
        .form-control, .form-select { border-radius: 15px; padding: 12px 15px; border: 2px solid #eee; margin-bottom: 15px; }
        .btn-post { background: linear-gradient(to right, #23a6d5, #23d5ab); border: none; color: white; padding: 12px; border-radius: 15px; font-weight: 600; transition: 0.3s; }
        .btn-post:hover { transform: scale(1.03); filter: brightness(1.1); color: white; }
        .btn-back { border-radius: 15px; padding: 12px; font-weight: 600; }
        .alert { border-radius: 15px; font-weight: 600; }
    </style>
</head>
<body>

    <div class="form-card">
        <div class="text-center mb-3" style="font-size: 40px;">🛠️</div>
        <h3>Post New Service</h3>
        <p class="text-center text-muted mb-4">Share your skills with the campus!</p>
        
        <?php if($success): ?>
            <div class="alert alert-success text-center"> <?php echo $success; ?> </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-danger text-center"> <?php echo $error; ?> </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">📌 Service Title</label>
                <input type="text" name="title" class="form-control" placeholder="E.g. Laptop Repair" required>
            </div>

            <div class="mb-3">
                <label class="form-label">📁 Category</label>
                <select name="category" class="form-select" required>
                    <option value="" selected disabled>Choose a category...</option>
                    <option value="Printing">Printing 🖨️</option>
                    <option value="Food & Drinks">Food & Drinks 🍔</option>
                    <option value="Academic Tutor">Academic Tutor 📚</option>
                    <option value="Technical Repair">Technical Repair 🛠️</option>
                    <option value="Others">Others ✨</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">📝 Description</label>
                <textarea name="description" class="form-control" rows="3" placeholder="Tell us more about what you offer..." required></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">💰 Price (RM)</label>
                    <input type="number" name="price" step="0.01" class="form-control" placeholder="0.00" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">🖼️ Image (JPG/PNG)</label>
                    <input type="file" name="service_image" class="form-control" required>
                </div>
            </div>

            <div class="d-grid gap-2 mt-3">
                <button type="submit" class="btn btn-post shadow-sm">Post Service Now 🎈</button>
                <a href="dashboard.php" class="btn btn-outline-secondary btn-back">Back to Dashboard</a>
            </div>
        </form>
    </div>

</body>
</html>