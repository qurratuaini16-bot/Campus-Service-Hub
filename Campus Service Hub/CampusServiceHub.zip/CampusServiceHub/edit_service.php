<?php
session_start();
include 'db_connect.php';

// Task 1e: Security Check
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Ambil data asal menggunakan Prepared Statement (Task 7: Security)
$stmt = $conn->prepare("SELECT * FROM services WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();

if (!$service) { 
    die("Service not found or you don't have permission to edit this."); 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = htmlspecialchars($_POST['title']);
    $category = $_POST['category'];
    $description = htmlspecialchars($_POST['description']);
    $price = $_POST['price'];

    // Update query
    $update_stmt = $conn->prepare("UPDATE services SET title=?, category=?, description=?, price=? WHERE id=? AND user_id=?");
    $update_stmt->bind_param("sssdii", $title, $category, $description, $price, $id, $user_id);
    
    if ($update_stmt->execute()) {
        header("Location: dashboard.php?msg=Updated successfully");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service | Campus Hub ✏️</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Fredoka', sans-serif;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .edit-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            border: 4px solid #fff;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            padding: 40px;
            width: 100%;
            max-width: 550px;
        }

        .form-label {
            font-weight: 600;
            color: #e73c7e;
            margin-left: 5px;
        }

        .form-control, .form-select {
            border-radius: 15px;
            padding: 12px 20px;
            border: 2px solid #eee;
            transition: 0.3s;
        }

        .form-control:focus {
            border-color: #23a6d5;
            box-shadow: 0 0 10px rgba(35, 166, 213, 0.2);
        }

        .btn-update {
            background: linear-gradient(135deg, #23d5ab, #23a6d5);
            border: none;
            border-radius: 15px;
            padding: 12px;
            font-weight: 600;
            color: white;
            transition: 0.3s;
        }

        .btn-update:hover {
            transform: scale(1.02);
            box-shadow: 0 5px 15px rgba(35, 166, 213, 0.4);
            color: white;
        }
    </style>
</head>
<body>

    <div class="container d-flex justify-content-center">
        <div class="edit-card">
            <div class="text-center mb-4">
                <h2 class="fw-bold" style="color: #e73c7e;">Edit Service ✏️</h2>
                <p class="text-muted">Update your service details below</p>
            </div>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">📌 Service Title</label>
                    <input type="text" name="title" class="form-control" 
                           value="<?php echo $service['title']; ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">📁 Category</label>
                    <select name="category" class="form-select" required>
                        <option value="Printing" <?php echo ($service['category'] == 'Printing') ? 'selected' : ''; ?>>Printing 🖨️</option>
                        <option value="Food & Drinks" <?php echo ($service['category'] == 'Food & Drinks') ? 'selected' : ''; ?>>Food & Drinks 🍔</option>
                        <option value="Academic Tutor" <?php echo ($service['category'] == 'Academic Tutor') ? 'selected' : ''; ?>>Academic Tutor 📚</option>
                        <option value="Technical Repair" <?php echo ($service['category'] == 'Technical Repair') ? 'selected' : ''; ?>>Technical Repair 🛠️</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">📝 Description</label>
                    <textarea name="description" class="form-control" rows="4" 
                              required><?php echo $service['description']; ?></textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label">💰 Price (RM)</label>
                    <input type="number" name="price" step="0.01" class="form-control" 
                           value="<?php echo $service['price']; ?>" required>
                </div>

                <button type="submit" class="btn btn-update w-100 mb-3">Save Changes 🚀</button>
                <a href="dashboard.php" class="btn btn-link w-100 text-decoration-none text-muted">Cancel & Go Back</a>
            </form>
        </div>
    </div>

</body>
</html>