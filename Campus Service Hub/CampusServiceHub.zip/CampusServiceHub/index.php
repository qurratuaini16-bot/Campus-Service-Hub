<?php
// Task 1e: Start session for login/logout navigation
session_start();
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover Services | Campus Service Hub 🔍</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        body {
            margin: 0; padding: 0; font-family: 'Fredoka', sans-serif;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%; animation: gradient 15s ease infinite;
            min-height: 100vh;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .navbar {
            background: rgba(255, 255, 255, 0.1) !important;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .hero-section { padding: 60px 0; color: white; text-shadow: 0 2px 4px rgba(0,0,0,0.1); }

        .search-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 10px; border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        #searchBox { border: none; border-radius: 15px; padding: 15px 25px; font-size: 1.1rem; }
        #searchBox:focus { box-shadow: none; }

        /* Category Pill Styles */
        .category-pill {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.4);
            padding: 8px 20px;
            border-radius: 50px;
            cursor: pointer;
            transition: 0.3s;
            display: inline-block;
            margin: 5px;
            text-decoration: none;
        }

        .category-pill:hover {
            background: white;
            color: #e73c7e;
            transform: translateY(-3px);
        }

        .results-container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 40px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            min-height: 400px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">🚀 Campus Service Hub</a>
            <div class="navbar-nav ms-auto align-items-center">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a class="nav-link text-white me-3" href="dashboard.php">Dashboard</a>
                    <a class="btn btn-danger btn-sm px-3 rounded-pill" href="logout.php">Logout</a>
                <?php else: ?>
                    <a class="btn btn-light btn-sm px-4 rounded-pill fw-bold" href="login.php" style="color: #e73c7e;">Login 🔑</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <header class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-3">Discover Campus Services ✨</h1>
            <p class="lead mb-4">Find the best skills and services offered by your fellow students.</p>
            
            <div class="row justify-content-center">
                <div class="col-md-7">
                    <div class="search-container mb-4">
                        <input type="text" id="searchBox" class="form-control" 
                               placeholder="🔍 Try searching 'printing', 'tutor', or 'food'..." 
                               onkeyup="liveSearch(this.value)">
                    </div>

                    <div class="mb-2">
                        <div class="category-pill" onclick="liveSearch('')">All 🌈</div>
                        <div class="category-pill" onclick="liveSearch('Printing')">Printing 🖨️</div>
                        <div class="category-pill" onclick="liveSearch('Food')">Food & Drinks 🍔</div>
                        <div class="category-pill" onclick="liveSearch('Tutor')">Academic Tutor 📚</div>
                        <div class="category-pill" onclick="liveSearch('Repair')">Technical Repair 🛠️</div>
                        <div class="category-pill" onclick="liveSearch('Other')">Other ✨</div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container mb-5">
        <div class="results-container shadow-lg">
            <div id="resultsArea">
                <div class="text-center text-white py-5">
                    <div class="spinner-border text-light mb-3" role="status"></div>
                    <p>Loading magic services...</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function liveSearch(query) {
            
            if(query !== '') {
                document.getElementById("searchBox").value = query;
            } else {
                document.getElementById("searchBox").value = '';
            }

            const resultsArea = document.getElementById("resultsArea");
            
            fetch('search_process.php?q=' + encodeURIComponent(query))
                .then(response => response.text())
                .then(data => {
                    resultsArea.innerHTML = data;
                })
                .catch(err => {
                    console.error('Error:', err);
                    resultsArea.innerHTML = "<div class='text-center text-white py-5'>Error loading services. 😕</div>";
                });
        }

        window.onload = () => liveSearch('');
    </script>

</body>
</html>