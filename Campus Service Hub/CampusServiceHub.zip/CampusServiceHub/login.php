<?php
// Task 1e: Secure session handling
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Task 7: Prevent XSS using htmlspecialchars
    $username = htmlspecialchars($_POST['username']); 
    $password = $_POST['password'];

    // Task 7: Use Prepared Statements to prevent SQL Injection
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        // Task 1b: Use password_verify() to check hashed password (REQUIRED)
        if (password_verify($password, $user['password'])) {
            // Task 1e: Store user session securely
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];

            // Redirect to Dashboard after success
            header("Location: dashboard.php");
            exit();
        } else {
            // Task 4c: Display clear error messages
            $error = "Oops! Wrong password ❌";
        }
    } else {
        $error = "User not found 🔍";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Campus Service Hub 🌈</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        /* Colorful Animated Gradient Background */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Fredoka', sans-serif;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 30px;
            padding: 40px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            text-align: center;
            border: 4px solid #fff;
            position: relative;
        }

        .emoji-header {
            font-size: 50px;
            margin-bottom: 10px;
        }

        h2 {
            font-weight: 600;
            color: #e73c7e;
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            text-align: left;
            font-weight: 600;
            color: #555;
            margin-bottom: 5px;
        }

        .form-control {
            border-radius: 15px;
            padding: 12px 20px;
            border: 2px solid #eee;
            margin-bottom: 20px;
            font-size: 1rem;
        }

        .form-control:focus {
            border-color: #23a6d5;
            box-shadow: 0 0 10px rgba(35, 166, 213, 0.2);
        }

        .btn-login {
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            border: none;
            color: white;
            padding: 15px;
            border-radius: 15px;
            font-weight: 600;
            width: 100%;
            font-size: 1.1rem;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 4px 15px rgba(255, 65, 108, 0.4);
        }

        .btn-login:hover {
            transform: scale(1.05) rotate(-1deg);
            filter: brightness(1.1);
        }

        .register-link {
            margin-top: 25px;
            font-size: 0.9rem;
            color: #666;
        }

        .register-link a {
            color: #e73c7e;
            text-decoration: none;
            font-weight: 600;
        }

        .alert {
            border-radius: 15px;
            font-weight: 600;
            background-color: #ffe5ec;
            color: #d81b60;
            border: none;
        }

        /* Floaties decor */
        .bubble {
            position: absolute;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            z-index: -1;
            animation: float 6s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body>

    <div class="bubble" style="width: 80px; height: 80px; top: 10%; left: 10%;"></div>
    <div class="bubble" style="width: 120px; height: 120px; bottom: 15%; right: 5%; animation-delay: 2s;"></div>

    <div class="login-card">
        <div class="emoji-header">👋✨</div>
        <h2>Hello Friend!</h2>
        <p class="text-muted">Welcome to Campus Service Hub</p>

        <?php if(isset($error)): ?>
            <div class="alert p-2 mb-4">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="mb-1">
                <label class="form-label">👤 Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter your username" required>
            </div>

            <div class="mb-1">
                <label class="form-label">🔑 Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn btn-login">Login 🚀</button>
        </form>

        <div class="register-link">
            New here? <a href="register.php">Create an account 🌈</a>
        </div>
    </div>

</body>
</html>